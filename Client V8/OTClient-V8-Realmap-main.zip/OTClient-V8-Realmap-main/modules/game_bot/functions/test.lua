local context = G.botContext

context.test = function() return context.info("test") end