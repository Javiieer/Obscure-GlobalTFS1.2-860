## Layouts overwrite files from `/data`
Foe example, if you have file `/data/images/background.png` and `/layouts/dragonball/images/background.png`, and dragonball layout is selected, then `/layouts/dragonball/images/background.png` will be loaded instead of `/data/images/background.png`.

## Dont make layout named `default`, this name is reserved
